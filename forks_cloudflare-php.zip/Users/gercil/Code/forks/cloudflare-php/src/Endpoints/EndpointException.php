<?php
/**
 * Created by PhpStorm.
 * User: junade
 * Date: 06/06/2017
 * Time: 14:24
 */

namespace Cloudflare\API\Endpoints;

class EndpointException extends \Exception
{
}
