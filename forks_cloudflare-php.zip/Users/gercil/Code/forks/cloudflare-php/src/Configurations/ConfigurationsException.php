<?php
/**
 * Created by PhpStorm.
 * User: junade
 * Date: 19/09/2017
 * Time: 16:57
 */

namespace Cloudflare\API\Configurations;

class ConfigurationsException extends \Exception
{
}
