<?php
/**
 * Created by PhpStorm.
 * User: junade
 * Date: 21/04/2017
 * Time: 06:52
 */

namespace Cloudflare\API\Adapter;

class JSONException extends \Exception
{
}
